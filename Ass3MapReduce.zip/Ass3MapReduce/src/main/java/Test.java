import org.apache.hadoop.io.Text;

public class Test {
    public static void main(String[] args) {
        System.out.println(map("publisher/pobj\t2578"));
    }

    public static String map(String value) {
        String[] dataRow = value.split("\t");
        if (dataRow.length != 2) return "error";
        String[] data = dataRow[0].split("/");
        if (data.length == 2) {
            return "A" +"\t"+ data[0] + "/" + data[1] + "\t" + dataRow[1];
        } else {
            if (data.length == 3) {
                return "B" +"\t"+ data[1] + "/" + data[2] + "\t" + data[0] + " " + dataRow[1];
            }
        }

return "error";
    }
}
