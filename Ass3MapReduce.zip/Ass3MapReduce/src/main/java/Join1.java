import java.io.IOException;

import java.util.LinkedList;
import java.util.List;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Partitioner;
import org.apache.hadoop.mapreduce.Reducer;


public class Join1 {
    public static class MapClass extends Mapper<LongWritable, Text, TagFeature, Text> {

        @Override
        public void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {
            String[] dataRow = value.toString().split("\t");
            if (dataRow.length != 2) return;
            String[] data = dataRow[0].split("/");
            if(data.length == 2){
                context.write(new TagFeature("A",data[0]+"/"+data[1]), new Text(dataRow[1]));
            }else {
                if (data.length == 3) {
                    context.write(new TagFeature("B", data[1] + "/" + data[2]), new Text(data[0] + " " + dataRow[1]));
                }
            }

        }
    }

    public static class ReduceClass extends Reducer<TagFeature, Text, Text, Text> {

        String currentTag = null;
        String currentKey = null;
        List<Text> table_count_f = new LinkedList<>();
        boolean writeMode = false;

        @Override
        public void reduce(TagFeature tagFeature, Iterable<Text> values, Context context) throws IOException, InterruptedException {
            if (currentKey == null || !currentKey.equals(tagFeature.getKey().toString())) {
                table_count_f.clear();
                writeMode = false;
            } else {
                writeMode = ((currentTag != null) && (!currentTag.equals(tagFeature.getTag().toString())) && (tagFeature.getTag().toString().equals("B")));
            }
            if (writeMode) {
                crossProduct(tagFeature.getKey().toString(), values, context);
                table_count_f.clear();
            }
            else {
                if (tagFeature.getTag().toString().equals("A")) {
                    for (Text value : values) {
                        Text toadd = new Text(value);
                        context.write(new Text("test"),new Text(tagFeature.toString()+"\t"+value.toString()));
                        table_count_f.add(toadd);
                    }
                }
            }
            currentTag = tagFeature.getTag().toString();
            currentKey = tagFeature.getKey().toString();
        }

        protected void crossProduct(String key, Iterable<Text> table2Values, Context context) throws IOException, InterruptedException {

            String counter_f = (table_count_f.toString()).substring(1,(table_count_f.toString()).length()-1);
            for (Text T : table2Values){
                String[] split = T.toString().split(" ");
                context.write(new Text(split[0]), new Text(key + " " + counter_f+ " " +split[1]));
            }
        }
    }

    public static class PartitionerClass extends Partitioner<TagFeature, Text> {
        // ensure that keys with same key are directed to the same reducer
        @Override
        public int getPartition(TagFeature key, Text value, int numPartitions) {
            return (key.hashCode() & Integer.MAX_VALUE) % numPartitions;
        }
    }
}