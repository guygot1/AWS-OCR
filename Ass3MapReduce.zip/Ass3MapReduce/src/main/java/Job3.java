import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Partitioner;
import org.apache.hadoop.mapreduce.Reducer;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class Job3 {

    public static class MapperClass extends Mapper<LongWritable, Text, Text, Text> {
        Set<String> golden ;

        protected void setup (Context context) throws IOException {
            try (BufferedReader in = new BufferedReader(new InputStreamReader(Main.class.getResourceAsStream("word-relatedness.txt")))) {
                golden = in.lines().parallel()
                        .map(line -> line.split("\t"))
                        .flatMap(strings -> Stream.of(strings[0], strings[1]))
                        .collect(Collectors.toSet());
            }
        }

        @Override
        protected void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {
            String[] dataRow = value.toString().split("\t");
            if(golden.contains(dataRow[0])){
                String[] data = dataRow[1].split(" ");
                context.write(new Text(dataRow[0]), new Text(data[0] + " " + data[1] + " " + data[2]));
            }

            // key:     word1
            // value:   word2 depLable total_count

        }
    }

    public static class PartitionerClass extends Partitioner<Text, Text> {
        public int getPartition(Text text, Text longWritable, int i) {
            return (text.hashCode() & Integer.MAX_VALUE) % i;
        }
    }

    public static class ReducerClass extends Reducer<Text, Text, Text, Text> {
        @Override
        protected void reduce(Text key, Iterable<Text> values, Context context) throws IOException, InterruptedException {
            long counter = 0;

            for (Text value: values) {
                String[] splitted = value.toString().split(" ");
                counter += Long.parseLong(splitted[2]);
                context.write(key, value);
                // key:     word1
                // value:   word2 depLable total_count
            }

            context.write(key, new Text(String.valueOf(counter)));
            context.getCounter("counter", "L").increment(counter);
            // key:     word1
            // value:   lexam_count
        }
    }
}

