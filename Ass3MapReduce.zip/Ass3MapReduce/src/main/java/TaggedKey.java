import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.WritableComparable;

public interface TaggedKey extends WritableComparable<TaggedKey> {
    Text getTag();
    Text getKey();
}