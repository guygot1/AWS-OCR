import org.apache.commons.lang3.math.NumberUtils;
import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.io.*;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Partitioner;
import org.apache.hadoop.mapreduce.Reducer;

import java.io.BufferedReader;
import java.io.IOException;

import java.io.InputStreamReader;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class Job2 {
    // Count L,f
    public static class JobMapper extends Mapper<LongWritable, Text, Text, LongWritable> {


        @Override
        protected void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {
            String[] dataRow = value.toString().split("\t");
            /*
             */
            if ((dataRow.length != 4) || !NumberUtils.isDigits(dataRow[2])) {
                return;
            }
            LongWritable occurrences = new LongWritable(Integer.parseInt(dataRow[2]));
            String[] syntactic = dataRow[1].split("\\s+");
            List<Feature> lst = new LinkedList<>();
            for (int i = 0; i < syntactic.length; i++) {
                lst.add(new Feature(syntactic[i]));
            }
            for (Feature f : lst) {
                if (f.getHead_index() != 0 && f.getWord().toLowerCase().matches(".*[a-z]+.*")) {
                    context.write(new Text(f.getWord() + "/" + lst.get(f.getHead_index() - 1).getWord() + "/" + f.getDep_lable()), occurrences);
                }
            }

        }
    }

    public static class JobReducer extends Reducer<Text, LongWritable, Text, LongWritable> {

        @Override
        public void reduce(Text key, Iterable<LongWritable> values, Context context) throws IOException, InterruptedException {
            LongWritable sum = new LongWritable(0);
            for (LongWritable counter : values) {
                sum.set(sum.get() + counter.get());
            }
            context.write(key, sum);
            //key = word feature
            //value = count(l,f)


            // key = feature
            //value= word count(l,f) count(f)
        }
    }

    public static class PartitionerClass extends Partitioner<Text, LongWritable> {
        @Override
        public int getPartition(Text key, LongWritable value, int numPartitions) {
            return (key.hashCode() & Integer.MAX_VALUE) % numPartitions;
        }
    }

}


