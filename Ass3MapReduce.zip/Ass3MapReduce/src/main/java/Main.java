import com.sun.tools.internal.xjc.reader.gbind.Sequence;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.SequenceFile;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.input.MultipleInputs;
import org.apache.hadoop.mapreduce.lib.input.SequenceFileInputFormat;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.jobcontrol.ControlledJob;
import org.apache.hadoop.mapreduce.lib.jobcontrol.JobControl;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;


import java.awt.*;
import java.io.*;

import java.nio.Buffer;
import java.util.LinkedList;
import java.util.Set;
import java.util.stream.Stream;
import java.util.stream.Collectors;

public class Main {


    public static void main(String[] args) throws IOException {


        if (args.length < 3) {
            return;
        }
        String INPUT = args[1];
        String OUTPUT1 = "s3://ass3mapreduce/outputs/output1";
        String OUTPUT2 = "s3://ass3mapreduce/outputs/output2";
        String OUTPUT3 = "s3://ass3mapreduce/outputs/output3";

        String FINALOUTPUT = args[2];

        try {
            Configuration conf = new Configuration();


            Job job1 = Job.getInstance(conf, "Job1");
            job1.setJarByClass(Job1.class);
            job1.setMapperClass(Job1.JobMapper.class);
//            job1.setCombinerClass(Job1.JobReducer.class);
            job1.setReducerClass(Job1.JobReducer.class);
            job1.setPartitionerClass(Job1.PartitionerClass.class);
            job1.setMapOutputKeyClass(Text.class);
            job1.setMapOutputValueClass(LongWritable.class);
            job1.setOutputKeyClass(LongWritable.class);
            job1.setOutputValueClass(Text.class);
            job1.setInputFormatClass(SequenceFileInputFormat.class);
            job1.setOutputFormatClass(TextOutputFormat.class);
            FileInputFormat.addInputPath(job1, new Path(INPUT));
            FileOutputFormat.setOutputPath(job1, new Path(OUTPUT1));


//            conf.setLong("counterN",(job1.getCounters().findCounter("counter", "N").getValue()));

            Job job2 = Job.getInstance(conf, "Job2");
            job2.setJarByClass(Job2.class);
            job2.setMapperClass(Job2.JobMapper.class);
            job2.setReducerClass(Job2.JobReducer.class);
            job2.setPartitionerClass(Job2.PartitionerClass.class);
            job2.setMapOutputKeyClass(Text.class);
            job2.setMapOutputValueClass(LongWritable.class);
            job2.setOutputKeyClass(Text.class);
            job2.setOutputValueClass(LongWritable.class);
            job2.setInputFormatClass(TextInputFormat.class);
            job2.setOutputFormatClass(TextOutputFormat.class);
            job2.setInputFormatClass(SequenceFileInputFormat.class);
            job2.setOutputFormatClass(TextOutputFormat.class);
            FileInputFormat.addInputPath(job2, new Path(INPUT));
            FileOutputFormat.setOutputPath(job2, new Path(OUTPUT2));


            Job join1 = Job.getInstance(conf, "Join1");
            join1.setJarByClass(Join1.class);
            join1.setMapperClass(Join1.MapClass.class);
            join1.setReducerClass(Join1.ReduceClass.class);
            join1.setPartitionerClass(Join1.PartitionerClass.class);
            join1.setMapOutputKeyClass(TagFeature.class);
            join1.setMapOutputValueClass(Text.class);
            join1.setOutputKeyClass(Text.class);
            join1.setOutputValueClass(Text.class);
            MultipleInputs.addInputPath(join1, new Path(OUTPUT1), TextInputFormat.class, Join1.MapClass.class);
            MultipleInputs.addInputPath(join1, new Path(OUTPUT2), TextInputFormat.class, Join1.MapClass.class);
            FileOutputFormat.setOutputPath(join1, new Path(OUTPUT3));

            ControlledJob controlledJob1 = new ControlledJob(job1, new LinkedList<>());
            ControlledJob controlledJob2 = new ControlledJob(job2, new LinkedList<>());
            ControlledJob controlledJoin1 = new ControlledJob(join1, new LinkedList<>());


            controlledJoin1.addDependingJob(controlledJob1);
            controlledJoin1.addDependingJob(controlledJob2);


            JobControl jc = new JobControl("JC");
            jc.addJob(controlledJob1);
            jc.addJob(controlledJob2);
            jc.addJob(controlledJoin1);


            Thread t = new Thread(jc);
            t.start();
            String oldStatusJ1 = null;
            String oldStatusJ2 = null;
            String oldStatusJ3 = null;

            while (!jc.allFinished()) {
                String status = jc.toString();
                String status2 = jc.toString();
                String status3 = jc.toString();
//                String status4= jc.toString();
//                String status5= jc.toString();
//
                if (!status.equals(oldStatusJ1)) {
                    System.out.println(status);
                    oldStatusJ1 = status;
                }
                if (!status2.equals(oldStatusJ2)) {
                    System.out.println(status2);
                    oldStatusJ2 = status2;
                }
                if (!status3.equals(oldStatusJ3)) {
                    System.out.println(status3);
                    oldStatusJ3 = status3;
                }

            }
//
//            Configuration conf4 = new Configuration();

//            Job job4 = Job.getInstance(conf4, "Join1");
//            job4.setJarByClass(Join1.class);
//            job4.setMapperClass(Join1.JobMapper4.class);
//            job4.setReducerClass(Join1.JobReducer4.class);
//            job4.setPartitionerClass(Join1.PartitionerClass4.class);
//            job4.setMapOutputKeyClass(Trigram.class);
//            job4.setMapOutputValueClass(LongWritableArray.class);
//            job4.setOutputKeyClass(Trigram.class);
//            job4.setOutputValueClass(DoubleWritable.class);
//            FileInputFormat.addInputPath(job4, new Path(OUTPUT5));
//            FileOutputFormat.setOutputPath(job4, new Path(FINALOUTPUT));
//            job4.setInputFormatClass(TextInputFormat.class);
//            job4.setOutputFormatClass(TextOutputFormat.class);
//            System.exit(job4.waitForCompletion(true) ? 0 : 1);
            System.exit(0);
        } catch (Exception e) {
            System.out.println("Exception catch in pipe line: " + e.getMessage());
            System.exit(1);
        }

    }


}

