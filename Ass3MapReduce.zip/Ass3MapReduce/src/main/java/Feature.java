
public class Feature {
    private String word;
    private String pos_tag;
    private String dep_lable;
    private int head_index;

    public Feature(String line) {
        String[] splitted_line = line.split("/");
        if (splitted_line.length == 4) {
            Stemmer stemmer = new Stemmer();
            stemmer.add(splitted_line[0].toCharArray(), splitted_line[0].length());
            stemmer.stem();
            this.word = stemmer.toString();
            this.pos_tag = splitted_line[1];
            this.dep_lable = splitted_line[2];
            this.head_index = Integer.parseInt(splitted_line[3]);
        } else if (splitted_line.length == 5) {
            this.word = "/";
            this.pos_tag = splitted_line[2];
            this.dep_lable = splitted_line[3];
            this.head_index = Integer.parseInt(splitted_line[4]);
        } else {
            this.word = "notGood";
            this.pos_tag = "notGood";
            this.dep_lable = "notGood";
            this.head_index = 0;
        }
    }

    public String getWord() {
        return word;
    }

    public String getPos_tag() {
        return pos_tag;
    }

    public String getDep_lable() {
        return dep_lable;
    }

    public int getHead_index() {
        return head_index;
    }
}
