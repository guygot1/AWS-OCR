
import org.apache.hadoop.io.Text;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

public class TagFeature implements TaggedKey  {
    private Text tag; //<"A"/"B">
    private Text id ; //Feature

    public TagFeature(){
        this.id = new Text();
        this.tag = new Text();
    }

    public TagFeature(String tag, String id){
        this.id = new Text(tag);
        this.tag =new Text (id);
    }
    @Override
    public Text getTag() {
        return tag;
    }
    @Override
    public Text getKey() {
        return id;
    }

    @Override
    public int compareTo(TaggedKey o) {
        if(this == o)
            return 0;
        TagFeature temp = (TagFeature)o;
        return (id.toString().compareTo(temp.getKey().toString())==0) ? tag.toString().compareTo(o.getTag().toString()) : id.toString().compareTo(temp.getKey().toString());
    }

    @Override
    public void write(DataOutput out) throws IOException {
        tag.write(out);
        id.write(out);
    }

    @Override
    public void readFields(DataInput in) throws IOException {
        tag.readFields(in);
        id.readFields(in);
    }

}
