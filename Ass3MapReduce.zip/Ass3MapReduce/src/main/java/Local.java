import com.amazonaws.services.elasticmapreduce.AmazonElasticMapReduce;
import com.amazonaws.services.elasticmapreduce.AmazonElasticMapReduceClient;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.elasticmapreduce.model.*;
import com.amazonaws.services.ec2.model.InstanceType;

public class Local {
    private static String CORPUS="s3://assignment3dsp/biarcs/biarcs.00-of-99";

    private static String FINALOUTPUT="s3://ass3mapreduce/outputs/";




    public static void main(String[] args) {


        AmazonElasticMapReduce emr = AmazonElasticMapReduceClient.builder().standard().withRegion(Regions.US_EAST_1).build();

        HadoopJarStepConfig Jarstep1 = new HadoopJarStepConfig()
                .withJar("s3://ass3mapreduce/jar/Ass3MapReduce.jar")
                .withMainClass("Local")
                .withArgs(CORPUS, FINALOUTPUT);

        StepConfig step1Config = new StepConfig()
                .withName("step1")
                .withHadoopJarStep(Jarstep1)
                .withActionOnFailure("TERMINATE_JOB_FLOW");


        JobFlowInstancesConfig instances = new JobFlowInstancesConfig()
                .withInstanceCount(4)
                .withMasterInstanceType(InstanceType.M4Large.toString())
                .withSlaveInstanceType(InstanceType.M4Large.toString())
                .withHadoopVersion("2.6.0")
                .withEc2KeyName("ec2-ass1")
                .withKeepJobFlowAliveWhenNoSteps(false)
                .withPlacement(new PlacementType("us-east-1a"));

        RunJobFlowRequest runFlowRequest = new RunJobFlowRequest()
                .withName("jobname")
                .withInstances(instances)
                .withSteps(step1Config)
                .withLogUri("s3://ass3mapreduce/logs/")
                .withServiceRole("EMR_DefaultRole")
                .withJobFlowRole("EMR_EC2_DefaultRole")
                .withReleaseLabel("emr-5.16.0");
//                .withAmiVersion("ami-0878fb723a9a1c5db");

        RunJobFlowResult runJobFlowResult = emr.runJobFlow(runFlowRequest);
        String jobFlowId = runJobFlowResult.getJobFlowId();
        System.out.println("Ran job flow with id: " + jobFlowId);
    }
}