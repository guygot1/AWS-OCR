//import org.apache.hadoop.io.LongWritable;
//import org.apache.hadoop.io.Text;
//import org.apache.hadoop.mapreduce.Mapper;
//import org.apache.hadoop.mapreduce.Partitioner;
//import org.apache.hadoop.mapreduce.Reducer;
//
//import java.io.IOException;
//import java.util.HashMap;
//import java.util.Map;
//import java.util.SortedSet;
//import java.util.TreeSet;
//
//public class Job4 {
//
//    public static class MapperClass extends Mapper<LongWritable, Text, NewPair, Text> {
//        @Override
//        protected void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {
//            String[] splitted_key_value = value.toString().split("\t");
//            String[] splitted_value = splitted_key_value[1].split(" ");
//
//            if(splitted_value.length == 1){
//                context.write(new NewPair(new Text(splitted_key_value[0] + "\t" + "a")), new Text(splitted_key_value[1]));
//                // key:     word1   'a'
//                // value:   count_l
//            }
//            else{
//                context.write(new NewPair(new Text(splitted_key_value[0] + "\t" + "b")), new Text(splitted_key_value[1]));
//                // key:     word1   'b'
//                // value:   word2 depLable count_f count_lf
//            }
//        }
//    }
//
//    public static class PartitionerClass extends Partitioner<NewPair, Text> {
//        public int getPartition(NewPair keyText, Text valText, int i) {
//            return (keyText.hashCode() & Integer.MAX_VALUE) % i;
//        }
//    }
//
//    public static class ReducerClass extends Reducer<NewPair, Text, Text, Text> {
//        private FeaturesVocabulary featuresVocabulary;
//        long lexam_counter = 0;
//        @Override
//        protected void setup(Context context) throws IOException, InterruptedException {
//            featuresVocabulary = new FeaturesVocabulary(context.getConfiguration().get("BUCKET_NAME"),
//                    context.getConfiguration().get("FEATURE_FILE"));
//            super.setup(context);
//        }
//
//        @Override
//        protected void reduce(NewPair key, Iterable<Text> values, Context context) throws IOException, InterruptedException {
//            Map<String, String> myFeatures = new HashMap<>();
//            long LCounter = context.getConfiguration().getLong("counter_l", 1);
//            boolean isLCount = false;
//
//            for (Text value: values) {
//                String unitedFormulas;
//                String[] splitted_value = value.toString().split(" ");
//                if (splitted_value.length == 3){
//                    long formula_1 = Long.parseLong(splitted_value[2]);
//                    double formula_2 = (double) formula_1/lexam_counter; // count(l,f) / count(l)
//                    double mone = (double) formula_1 / LCounter;
//                    double mechane = ((double) lexam_counter / LCounter) * ((double) Long.parseLong(featuresVocabulary.getFeatures().get(splitted_value[0] + "_" + splitted_value[1])) / LCounter);
//                    double formula_3;
//                    double formula_4;
//                    if (mechane != 0) {
//                        formula_3 = (Math.log(mone / mechane)) / Math.log(2);
//                        formula_4 = (mone - mechane) / Math.sqrt(mechane);
//                    }
//                    else {
//                        formula_3 = Double.MAX_VALUE;
//                        formula_4 = Double.MAX_VALUE;
//                    }
//
//                    unitedFormulas = formula_1 + " " + formula_2 + " " + formula_3 + " " + formula_4;
//                    // form1 form2 form3 form4
//                }
//                else{
//                    lexam_counter = Long.parseLong(value.toString());
//                    isLCount = true;
//                    break;
//                }
//                myFeatures.put(splitted_value[0] + "_" + splitted_value[1], unitedFormulas);
//            }
//
//
//            if(!isLCount) {
//                for (String feature : featuresVocabulary.getFeatures().keySet()) {
//                    if (!myFeatures.containsKey(feature)) {
//                        myFeatures.put(feature, "0");
//                    }
//                }
//
//
//                StringBuilder vector1 = new StringBuilder();
//                StringBuilder vector2 = new StringBuilder();
//                StringBuilder vector3 = new StringBuilder();
//                StringBuilder vector4 = new StringBuilder();
//                for (String feature : new TreeSet<>(myFeatures.keySet())) {
//                    String[] splitted = myFeatures.get(feature).split(" ");
//                    vector1.append(splitted[0]).append(" ");
//                    vector2.append(splitted[1]).append(" ");
//                    vector3.append(splitted[2]).append(" ");
//                    vector4.append(splitted[3]).append(" ");
//                }
//
//                context.write(key.getKey(), new Text(vector1.toString()));
//                context.write(key.getKey(), new Text(vector2.toString()));
//                context.write(key.getKey(), new Text(vector3.toString()));
//                context.write(key.getKey(), new Text(vector4.toString()));
//            }
//            // key:     word1
//            // value:   lexam_count
//        }
//    }
//}
//
